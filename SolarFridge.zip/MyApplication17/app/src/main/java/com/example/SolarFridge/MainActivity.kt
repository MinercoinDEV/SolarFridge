

//Copyright (c) <2023> <KabosuDEV>

//Permission is hereby granted, free of charge, to any person obtaining a copy
//of this software and associated documentation files (the "Software"), to deal
//in the Software without restriction, including without limitation the rights
//to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//copies of the Software, and to permit persons to whom the Software is
//furnished to do so, subject to the following conditions:

//The above copyright notice and this permission notice shall be included in all
//copies or substantial portions of the Software.

//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//SOFTWARE.

package com.example.SolarFridge
import android.Manifest
import android.animation.ArgbEvaluator
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    private val MY_PERMISSIONS_REQUEST_ACCESS_LOCATION = 1

    private lateinit var bluetoothAdapter: BluetoothAdapter
    private lateinit var bluetoothSocket: BluetoothSocket
    private lateinit var outputStream: OutputStream
    private lateinit var inputStream: InputStream

    private lateinit var currentTempTextView: TextView
    private lateinit var targetTempTextView: TextView
    private lateinit var outsideTempTextView: TextView
    private lateinit var batteryChargeTextView: TextView
    private lateinit var tempSeekBar: SeekBar
    private lateinit var sendButton: androidx.appcompat.widget.AppCompatButton
    private lateinit var connectButton: androidx.appcompat.widget.AppCompatButton
    private lateinit var batteryImageView: ImageView
    private lateinit var toolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        currentTempTextView = findViewById(R.id.currentTempTextView)
        targetTempTextView = findViewById(R.id.targetTempTextView)
        outsideTempTextView = findViewById(R.id.outsideTempTextView)
        batteryChargeTextView = findViewById(R.id.batteryChargeTextView)
        tempSeekBar = findViewById(R.id.tempSeekBar)
        sendButton = findViewById(R.id.sendButton)
        connectButton = findViewById(R.id.connectButton)
        batteryImageView = findViewById(R.id.batteryImageView)

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

        sendButton.setOnClickListener {
            val targetTemp = tempSeekBar.progress / 10.0
            sendTemperature(targetTemp.toString())
        }

        connectButton.setOnClickListener {
            checkPermissionsAndConnect()
        }

        tempSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            @SuppressLint("SetTextI18n")
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val targetTemp = progress / 10.0
                targetTempTextView.text = "Zadana temperatura: ${targetTemp}°C"

                // calculate color for the current temperature
                val colorEvaluator = ArgbEvaluator()

                // modify fraction to be between 0 (for 0 degrees) and 1 (for 20 degrees)
                val fraction = ((targetTemp - 0) / (20 - 0)).coerceIn(0.0, 1.0)

                val color = colorEvaluator.evaluate(
                    fraction.toFloat(),
                    ContextCompat.getColor(this@MainActivity, R.color.coldest_color),
                    ContextCompat.getColor(this@MainActivity, R.color.hottest_color)
                ) as Int

                targetTempTextView.setTextColor(color)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })


    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_copyright -> {
                val intent = Intent(this, CopyrightActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun checkPermissionsAndConnect() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                // This is called if user has denied the permission before
                // In this case I am just asking the permission again
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                    MY_PERMISSIONS_REQUEST_ACCESS_LOCATION)

            } else {
                val builder = AlertDialog.Builder(this)
                builder.apply {
                    setMessage("Da bi se povezao s Bluetooth uređajem, ova aplikacija zahtijeva dozvolu za pristup obližnjim uređajima. ")
                    setTitle("Permission required")
                    setPositiveButton("OK") { _, _ ->
                        ActivityCompat.requestPermissions(this@MainActivity,
                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                            MY_PERMISSIONS_REQUEST_ACCESS_LOCATION)
                    }
                    setNegativeButton("Cancel", null)
                    show()
                }
            }
        } else {
            // If we have the permissions, initiate Bluetooth connection
            connectToDevice()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>,
                                            grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            MY_PERMISSIONS_REQUEST_ACCESS_LOCATION -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    connectToDevice()
                }
                return
            }
            else -> {
                // Ignore all other requests.
            }
        }
    }

    private fun connectToDevice() {
        try {
            val device: BluetoothDevice = bluetoothAdapter.getRemoteDevice("20:16:11:17:08:37")
            val uuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB") // Standard SerialPortService ID
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_CONNECT
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return
            }
            bluetoothSocket = device.createRfcommSocketToServiceRecord(uuid)
            bluetoothSocket.connect()
            outputStream = bluetoothSocket.outputStream
            inputStream = bluetoothSocket.inputStream

            startReading()
        } catch (e: Exception) {
            Log.e("MainActivity", "Error connecting to device", e)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun startReading() {
        Thread {
            var buffer = ""
            while (true) {
                try {
                    val available = inputStream.available()
                    if (available > 0) {
                        val bytes = ByteArray(available)
                        inputStream.read(bytes, 0, available)
                        buffer += String(bytes)

                        // Check if we have a complete message in the buffer
                        val newlineIndex = buffer.indexOf('\n')
                        if (newlineIndex != -1) {
                            val data = buffer.substring(0, newlineIndex)
                            buffer = buffer.substring(newlineIndex + 1)

                            val dataParts = data.split(";")
                            if (dataParts.size >= 4) {
                                val currentTemp = dataParts[0].toDouble()
                                val targetTemp = dataParts[1].toDouble()
                                val outsideTemp = dataParts[2].toDouble()
                                val voltage = dataParts[3].toDouble()

                                // calculate color for the current temperature
                                val colorEvaluator = ArgbEvaluator()

                                // modify fraction to be between 0 (for 0 degrees) and 1 (for 20 degrees)
                                val fraction = ((currentTemp - 0) / (20 - 0)).coerceIn(0.0, 1.0)

                                val color = colorEvaluator.evaluate(
                                    fraction.toFloat(),
                                    ContextCompat.getColor(this@MainActivity, R.color.coldest_color),
                                    ContextCompat.getColor(this@MainActivity, R.color.hottest_color)
                                ) as Int

                                runOnUiThread {
                                    currentTempTextView.text = "Trenutna temperatura: $currentTemp°C"
                                    currentTempTextView.setTextColor(color)
                                    targetTempTextView.text = "Zadana temperatura: $targetTemp°C"
                                    outsideTempTextView.text = "Vanjska temperatura: $outsideTemp°C"
                                    setBatteryCharge(voltage)
                                }
                            }
                        }
                    }
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }.start()
    }




    private fun sendTemperature(temp: String) {
        if (::outputStream.isInitialized) {
            val tempWithNewLine = "$temp\n"
            outputStream.write(tempWithNewLine.toByteArray())
        } else {
            Toast.makeText(this, "Please connect to the Bluetooth module first", Toast.LENGTH_SHORT).show()
        }
    }


    @SuppressLint("SetTextI18n")
    private fun setBatteryCharge(voltage: Double) {
        val chargePercent = ((voltage - 10) / 4.4 * 100).toInt().coerceIn(0, 100)
        batteryChargeTextView.text = "Napunjenost akumulatora: $chargePercent%"

        val drawableId = when {
            chargePercent >= 75 -> R.drawable.battery_100
            chargePercent >= 50 -> R.drawable.battery_75
            chargePercent >= 25 -> R.drawable.battery_50
            else -> R.drawable.battery_0
        }

        batteryImageView.setImageResource(drawableId)
    }
}
