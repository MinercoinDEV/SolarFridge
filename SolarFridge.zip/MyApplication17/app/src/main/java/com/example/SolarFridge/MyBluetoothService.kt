package com.example.SolarFridge

class MyBluetoothService {

}
